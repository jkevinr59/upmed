@extends('layouts.dashboard')
@section('content')
	<script type="text/javascript">
	$(document).ready(function(){
		$('#nav-track').addClass('selected');
	});		
	</script>
@endsection