
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Upmed : Kenali, Pahami, Pelihara Kesehatan Anda</title>
    <!-- Core CSS - Include with every page -->
    <link href="public/css/bootstrap.min.css" rel="stylesheet">
    <link href="public/css/font-awesome.css" rel="stylesheet">

    <!-- Page-Level Plugin CSS - Dashboard -->
    <link href="public/css/morris-0.4.3.min.css" rel="stylesheet">
    <link href="public/css/timeline.css" rel="stylesheet">
    <!-- SB Admin CSS - Include with every page -->
    <link href="public/css/sb-admin.css" rel="stylesheet">
    

</head>

<body>

    <div id="wrapper">

        <nav class="navbar navbar-default navbar-fixed-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="">UPMED</a>
            </div>
            <!-- /.navbar-header -->
			<ul class="nav navbar-top-links navbar-left">
                    <li><a href="#">Dashboard</a></li>
                    <li><a href="#">Track</a></li>
                    <li><a href="#">Layanan</a></li>
                    <li><a href="#">Profile</a></li>
             </ul>						
            <ul class="nav navbar-top-links navbar-right">         
                <!-- /.dropdown -->
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-fw"></i>  <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="#"><i class="fa fa-user fa-fw"></i> User Profile</a>
                        </li>
                        <li><a href="#"><i class="fa fa-gear fa-fw"></i> Settings</a>
                        </li>
                        <li class="divider"></li>
                        <li><a href="login.html"><i class="fa fa-power-off fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->

            <div class="navbar-default navbar-static-side" role="navigation">
                <div class="sidebar-collapse">
                	<br/>  <br/>
                   <center><img src="https://platform-static-files.s3.amazonaws.com/premierleague/photos/players/250x250/p66749.png" class="img-responsive" alt="Cinque Terre" width="100" height="100"> </center> <br/>  
                   <center><h4><b>Lukaku</b></h4></center>
                   
                   <center>Football Player</center>
                   <center><i class="glyphicon glyphicon-map-marker"><b>Surabaya</b></i></center>
                   <center></center>
                   <br/>  <br/>
                   <center><b>Tentang Kondisi Tubuh</b></center><br/><br/>
                   <div class="col-md-6">
                   	Berat Badan
                   </div>
                   <div class="col-md-6">
                   
                   &nbsp;&nbsp; &nbsp; &nbsp;&nbsp;&nbsp; &nbsp; &nbsp; Umur
                   </div>
                   <div class="col-md-6">
                   	<b>70 kg</b>
                   </div>
                   <div class="col-md-6">
                   	&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<b>34</b>
                   </div><br/><br/><br/><br/>
                   <div class="col-md-6">
                   	<img src="https://cdn.thinglink.me/api/image/860079451885535233/1240/10/scaletowidth" class="img-responsive" alt="Cinque Terre" width="50" height="100">
                   </div>
                   <div class="col-md-6">
                   	Tinggi Badan
                   	<b>172 cm</b>
                   </div><br/><br/><br/><br/>
                   <div class="col-md-6">
                   	Newest GDA
                   </div>
                   <div class="col-md-6">
                   
                   &nbsp;&nbsp; &nbsp; &nbsp;&nbsp;&nbsp; &nbsp; &nbsp; Lemak
                   </div>
                   <div class="col-md-6">
                   	<b>-</b>
                   </div>
                   <div class="col-md-6">
                   	&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<b>15%</b>
                   </div><br/><br/><br/><br/>
                   <center><a href="#" class="btn btn-default btn-round-lg btn-lg">Edit Profile&nbsp; &nbsp;<i class="fa fa-cog" aria-hidden="true"></i></a></center>
					<br/><br/>
					
                   <center>UPMED 2017</center>
                   <center>All Right Reserved</center>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>

        <div id="page-wrapper">
            <!--<div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Dashboard</h1>
                </div>-->
                <!-- /.col-lg-12 -->
            <!--</div>-->
            <!-- /.row -->
                @yield('content')
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- Core Scripts - Include with every page -->
    <script src="public/js/jquery.min.js"></script>
    <script src="public/js/bootstrap.min.js"></script>
    <script src="public/js/jquery.metisMenu.js"></script>

    <!-- Page-Level Plugin Scripts - Dashboard -->
    <script src="public/js/raphael-2.1.0.min.js"></script>
    <script src="public/js/morris.js"></script>

    <!-- SB Admin Scripts - Include with every page -->
    <script src="public/js/sb-admin.js"></script>


</body>

</html>
