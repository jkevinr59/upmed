<?php

/**
 * Default config values
 */
return [
    'bootstrapVersion' => '3.3.7',
    'jqueryVersion' => '2.1.0',
    'icon_prefix' => 'glyphicon',
    'icon_tag' => 'span'
];
